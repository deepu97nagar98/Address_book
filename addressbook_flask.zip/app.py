from flask import Flask
from controllers import book

app = Flask(__name__)
app.register_blueprint(book)

if __name__ == '__main__':
    app.run(port=5000)
